-- MySQL dump 10.10
--
-- Host: west.yaploud.com    Database: dev
-- ------------------------------------------------------
-- Server version	5.0.24a-standard-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `email` varchar(64) NOT NULL,
  `username` varchar(64) NOT NULL,
  `password` varchar(32) NOT NULL,
  `update_timestamp` datetime NOT NULL,
  `last_name` varchar(32) NOT NULL,
  `first_name` varchar(32) NOT NULL,
  `description` varchar(2048) default NULL,
  `user_icon` varchar(256) default NULL,
  `cookie` char(32) NOT NULL default '',
  `ip` varchar(15) NOT NULL default '',
  `session` char(32) NOT NULL default '',
  `userid` varchar(32) NOT NULL,
  PRIMARY KEY  (`email`),
  UNIQUE KEY `userid` (`userid`),
  KEY `user_email_idx` (`email`),
  KEY `user_username_idx` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--


/*!40000 ALTER TABLE `user` DISABLE KEYS */;
LOCK TABLES `user` WRITE;
INSERT INTO `user` VALUES ('tully_tim@yahoo.com','timt','06d80eb0c50b49a509b49f2424e8c805','2007-07-21 23:40:15','tully','tim',NULL,NULL,'','216.145.49.21','7ju2q8g9d3pg8s127mk7b5mcf1','timt'),('cmuchris@yahoo.com','chris','5f4dcc3b5aa765d61d8327deb882cf99','2007-07-22 21:34:24','hinrichs','chris',NULL,NULL,'','129.42.184.35','ivq6n92cfu37mj0akr9a4jm2m4','chris'),('rahul.arora@yaploud.com','yapper','439ed537979d8e831561964dbbbd7413','2007-07-23 00:12:07','arora','rahul',NULL,NULL,'jsp7do0smma9vrf3sjk4n4e9l7','204.16.157.225','jsp7do0smma9vrf3sjk4n4e9l7','yapper'),('rishiarora1@hotmail.com','RishiArora1','a0d9c281caf1eec6fab8c47a19a0bd56','2007-07-23 01:23:12','arora','rishi',NULL,NULL,'','','','RishiArora1'),('rahularora55@gmail.com','ra','439ed537979d8e831561964dbbbd7413','2007-07-24 12:13:49','Arora','Rahul',NULL,NULL,'cg6f440ic70ejs9tcse1bbue82','204.16.157.225','cg6f440ic70ejs9tcse1bbue82','ra'),('test@testing.com','test','098f6bcd4621d373cade4e832627b4f6','2007-07-30 16:47:34','Testing','Test',NULL,NULL,'','216.145.49.5','mtahf9n7ks3556tm7dbshghfa3','test'),('dthinc@yahoo.com','dthinc','c3aa0a8f4166cccc2597bd73c07c67af','2007-07-30 17:59:02','Heidgerken','Daren',NULL,NULL,'','209.172.121.194','t4vqp2vm6268kvo0akk2cl16m3','dthinc'),('mvangati@gmail.com','mv','0cbec80aea8ee48598f30773e90d9984','2007-09-01 10:01:51','Vangati','Mahender',NULL,NULL,'7amnt0mtm0658mae9en1vh8qv1','204.16.157.225','7amnt0mtm0658mae9en1vh8qv1','mv'),('lejohnson@revedia.com','Lawrence','1a4e6cdb8c5a9b25aebdb38c4ad7245e','2007-08-30 14:09:22','Johnson','Lawrence ',NULL,NULL,'','','','Lawrence'),('sonaarora75@yahoo.com','Sk','ff70a133340cc883942e7c9e7dc0838c','2007-09-08 02:29:42','Arora','Sona',NULL,NULL,'','','','Sk'),('deepthi_kovvuri@yahoo.com','dk','2b495edc547db37ea0204693473c5c6d','2007-09-08 10:01:13','Kovvuri','Deepthi',NULL,NULL,'','24.5.139.64','puf3kc17f8n2439idc953ekrs4','dk'),('otherviv@gmail.com','viv','04a5a8fe2c268edfeb57475e1302fb81','2007-10-15 22:39:21','Kam','Vivian',NULL,NULL,'','24.6.225.247','ol2mr6092fnbacglf5tbo832r6','viv'),('suresh.k.venkatesan@gmail.com','sureshv','04a5a8fe2c268edfeb57475e1302fb81','2007-11-06 06:56:46','Venkatesan','Suresh',NULL,NULL,'7tm86lrh7sbr9mh7q4mqc1q176','76.204.30.166','7tm86lrh7sbr9mh7q4mqc1q176','sureshv'),('mark.yoshikawa@west.cmu.edu','jonny5','04a5a8fe2c268edfeb57475e1302fb81','2007-10-01 19:01:11','Yoshikawa','Mark',NULL,NULL,'','209.172.121.194','n9jh0rbd7jgnirm707dp6ise14','jonny5'),('alvinabad@alumni.cmu.edu','alvin','b9974191c2e2806abb0ed0fe229ca0f6','2007-11-08 23:13:17','Abad','Alvin',NULL,NULL,'cuvqvr10afa5rl3f9tn0ihlpv7','204.16.157.225','cuvqvr10afa5rl3f9tn0ihlpv7','alvin'),('kenckchin@gmail.com','KenTepper','dbc17652b17cd3dc9e461a2b1065ea23','2007-11-15 07:10:33','Chin','Ken',NULL,NULL,'pqb9lrmbumo7rcsniu1hk6t2g6','24.4.252.4','pqb9lrmbumo7rcsniu1hk6t2g6','KenTepper'),('sdfsd','fsfdf','202cb962ac59075b964b07152d234b70','2007-11-19 00:17:34','sdfsdf','dsfsdf',NULL,NULL,'','','','fsfdf'),('alvinabad@yahoo.com','alvin2','b9974191c2e2806abb0ed0fe229ca0f6','2007-11-19 01:33:01','abad','alvin',NULL,NULL,'dsiibr5cissdat8cr41viad976','67.180.122.131','dsiibr5cissdat8cr41viad976','alvin2'),('yaploud@yaplous.com','yaploud','fcff4f5b8abd572677875aaec2c44b32','2007-12-08 05:18:03','loud','yap',NULL,NULL,'','','','yaploud'),('rishi.arora@vsnl.net','grouping123','a0d9c281caf1eec6fab8c47a19a0bd56','2008-01-22 01:05:57','arora','rishi',NULL,NULL,'v78q0nq00tt9fh2sf9rf0jpiq5','220.225.42.205','v78q0nq00tt9fh2sf9rf0jpiq5','grouping123'),('tripathipra_bit@yahoo.com','Pradeeptri','dc31316e6c1a2e93bf4cf00255aa7015','2008-01-22 01:43:29','Tripathi','Pradeep',NULL,NULL,'2qujgk7uo6livgmum57r2ml150','203.191.35.100','2qujgk7uo6livgmum57r2ml150','Pradeeptri'),('pradeep.tripathi@capgemini.com','Pradeep','dc31316e6c1a2e93bf4cf00255aa7015','2008-01-22 02:36:45','Tripathi','Pradeep',NULL,NULL,'a2899kieg93922tb43us8ss6j3','217.169.51.254','a2899kieg93922tb43us8ss6j3','Pradeep'),('alvinabad@cmu.edu','alvin3','b9974191c2e2806abb0ed0fe229ca0f6','2008-01-24 21:19:08','Abad','Alvin',NULL,NULL,'','','','alvin3'),('shukla.nidhi@hotmail.com','nshukla','2f23fa3579f3f75175793649115c1b25','2008-01-31 06:46:31','Shukla','Nidhi',NULL,NULL,'fnsvdabd5s82t1g476p78rejs4','217.169.51.254','fnsvdabd5s82t1g476p78rejs4','nshukla'),('itsmeonly18@rediffmail.com','user1','823da4223e46ec671a10ea13d7823534','2008-02-05 07:07:40','Last1','First1',NULL,NULL,'5ugs62a9mqdku2uss7bevhe8f2','217.169.51.254','5ugs62a9mqdku2uss7bevhe8f2','user1'),('asriar@cmu.edu','asriar@cmu.edi','4112fc8db5e3603d61dc7ed4916b291e','2008-04-06 00:24:45','Riar','Amandeep',NULL,NULL,'m1qjgept77v0nh74674mpptjb0','24.4.39.82','m1qjgept77v0nh74674mpptjb0','asriar@cmu.edi'),('one@none.com','one@none.com','4112fc8db5e3603d61dc7ed4916b291e','2008-04-06 01:15:17','mmm','mmmm',NULL,NULL,'','','','one@none.com'),('aalvin@andrew.cmu.edu','alvin66','67f361b7b9a8f2c3a47de5155a63c438','2008-04-07 12:32:56','abad','alvin',NULL,NULL,'','','','alvin66'),('seeya32@gmail.com','SeeYa32','2fca174dfc3645377ab9445d038c7c88','2008-04-07 15:21:08','Smith','Bobby',NULL,NULL,'jf75icf4na4nsjq5d9pi15k572','76.184.239.228','jf75icf4na4nsjq5d9pi15k572','SeeYa32'),('aman@nowhere.com','aman','4112fc8db5e3603d61dc7ed4916b291e','2008-04-07 16:18:22','Riar','Amandeep',NULL,NULL,'','','','aman'),('ariar@andrew.cmu.edu','Rexi','4112fc8db5e3603d61dc7ed4916b291e','2008-04-07 16:19:48','B','Rexi',NULL,NULL,'','','','Rexi'),('arora_rahul@yahoo.com','yapper1','439ed537979d8e831561964dbbbd7413','2008-04-10 14:57:09','arora','rahul',NULL,NULL,'nbkp31d3aetu3pqha3j82d9vq2','204.16.157.225','nbkp31d3aetu3pqha3j82d9vq2','yapper1'),('chandra@grajax.com','chandra','5903d9e9a8884c8c04ad16559446735a','2008-04-16 10:32:17','yeleshwarapu','chandra',NULL,NULL,'uaqjmj2ki2c6604ns9hr97ev64','148.87.1.172','uaqjmj2ki2c6604ns9hr97ev64','chandra');
UNLOCK TABLES;
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

