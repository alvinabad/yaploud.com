-- MySQL dump 10.10
--
-- Host: west.yaploud.com    Database: dev
-- ------------------------------------------------------
-- Server version	5.0.24a-standard-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `chat_url_tag`
--

DROP TABLE IF EXISTS `chat_url_tag`;
CREATE TABLE `chat_url_tag` (
  `id` bigint(20) NOT NULL auto_increment,
  `chat_url_id` int(11) NOT NULL,
  `tag` varchar(996) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `chat_url_id` (`chat_url_id`,`tag`),
  FULLTEXT KEY `tag` (`tag`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chat_url_tag`
--


/*!40000 ALTER TABLE `chat_url_tag` DISABLE KEYS */;
LOCK TABLES `chat_url_tag` WRITE;
INSERT INTO `chat_url_tag` VALUES (1,144,'events'),(2,72,'social network'),(3,72,'myspace'),(4,2,'myspace'),(5,2,'social network'),(6,1,'news'),(7,1,'events'),(8,63,'stocks'),(9,63,'bonds'),(10,3,'news'),(11,145,'news'),(12,146,'money'),(13,1,'CNN'),(14,63,'money'),(15,63,'banking'),(16,63,'etrade'),(17,63,'financial'),(18,16,'silicontap'),(19,63,'trade'),(20,8,'University Masters Excellent'),(21,2,'blog'),(22,8,'school'),(23,150,'news'),(24,150,'rss'),(25,1,'democrat'),(26,1,'US');
UNLOCK TABLES;
/*!40000 ALTER TABLE `chat_url_tag` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

